# 7 Tools Spam Sms

![IMG_20200313_140123](https://user-images.githubusercontent.com/59508497/76597574-57dc1500-6533-11ea-9cba-b568e1c875c6.JPG)

```

Indonesia :

Kode Ini Di Buat Untuk Menjahili Teman Kalian Yang Sedang Asik Mabar 🤣

```

```

Inggris : 

This Code Is Made To Judge Your Friends Who Are Playing The Game 🤣

```

# Installation ( Penginstalan )

```

Termux :

$ pkg install git

$ pkg install python2

$ pip2 install requests

$ pip2 install mechanize

$ git clone https://github.com/Fukur0-3XP/SpamSms

$ cd SpamSms

$ python2 Spam.py

Kali Linux :

$ sudo apt-get install git

$ sudo apt install python-pip

$ pip2 install mechanize

$ pip2 install requests

$ git clone https://github.com/Fukur0-3XP/SpamSms

$ cd SpamSms

$ python2 Spam.py

```

# Info

```

Creator : ./FUKUR0-3XP

Team : Black Coders Anonymous Satanic Exploiter Team

Instagram : ricko.3xp_

Email : 3xp.fukur0@gmail.com

```
